# plot CNV of Lung cancer
# 20161128
# wupz

# source scripts
source('/lustre/user/liclab/wupz/dosageEffect/scripts/DrawCNVFigure.R')
library(limma)

# 1. read data
# 1.1 CNV Data of A549
A549_hic_cnv_40k_ploidy2 <- read.table('/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/a549_10_4/ploidy_2_resolution_40000/A549_10_4.fastqclean.trim.fq.samrmp.merge.bam_ratio.txt', header = T, stringsAsFactors = F)
A549_hic_cnv_40k_ploidy3 <- read.table('/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/a549_10_4/ploidy_3_resolution_40000/A549_10_4.fastqclean.trim.fq.samrmp.merge.bam_ratio.txt', header = T, stringsAsFactors = F)
dim(A549_hic_cnv_40k_ploidy2) # [1] 77403     5
head(A549_hic_cnv_40k_ploidy3)
dim(A549_hic_cnv_40k_ploidy2) # [1] 77403     5
head(A549_hic_cnv_40k_ploidy3)

# 2.1 Plot CNV of a549
png( filename = 'a549_10_4.png', width = 1536, height = 1280)

# par(cex = 3, lwd = 2, mar = c(1, 2, 2, 0.5), mgp = c(0.8,0,0), tcl = 0.1, cex.lab = 1, cex.axis = 0.8, font = 2, xaxs = 'i')
# A549_hic_cnv_40k_ploidy2
DrawCNVFigure(CNV_data = A549_hic_cnv_40k_ploidy2, ploidy = 2, 
              mode = 'horizontal', ylab = '', main = '', x_axis_lab = T,
              filename = 'a549_10_4.png')
DrawCNVFigure(CNV_data = A549_hic_cnv_40k_ploidy3, ploidy = 3, 
              mode = 'horizontal', xlab = "", ylab = '', 
              main = 'a549_10_4, 40kb, ploidy 3', 
              x_axis_lab = T, 
              filename = 'a549_10_4.png')
# plot all cnv data
lung_cancer_samples <- c("5534N", "5534T_10_4", "5534T_10_5", "5534T_10_6", "6405N", "6405T", "a549_10_4", "a549_10_5", "a549_10_6")
file_name <- c("ploidy_2_resolution_40000", "ploidy_2_resolution_500000", "ploidy_3_resolution_40000", "ploidy_3_resolution_500000")
k = 0
for ( i in 1:9) {
  tmp_ploidy <- strsplit2(file_name, split = "_")
  for (j in 1:4) {
    k = k +1
    # set plotting directory
    tmp_plot_dir <- paste(getwd(), lung_cancer_samples[i], file_name[j], sep = "/")
    tmp_cnv_file_name <- list.files(paste(lung_cancer_samples[i], file_name[j], sep = "/"), pattern = "ratio.txt$")
    print(paste( "Read file of", k, paste(tmp_plot_dir, tmp_cnv_file_name, sep = "/"), sep = ":") )
    # read cnv datatmp_cnv_file_name 
    tmp_cnv_file <- read.table(file = paste(tmp_plot_dir, tmp_cnv_file_name, sep = "/"), header = T, stringsAsFactors = F)

    # plot cnv
    DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = as.integer( tmp_ploidy[j, 2] ), 
                  mode = 'horizontal', xlab = "", ylab = '', 
                  main = paste(lung_cancer_samples[i],file_name[j] , sep = ", ") , 
                  x_axis_lab = T,
                  filename = paste(getwd(), "/", lung_cancer_samples[i],"_", file_name[j] , ".png", sep = "") )
    print("Done")
  }
}



tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/a549_10_4"
tmp_cnv_file_name <- c("ploidy_2_resolution_40000_contaminationAdjustment", "ploidy_2_resolution_40000_map", "ploidy_2_resolution_40000_map_contaminationAdjustment")
for (i in 1:3 ) {
  tmp_cnv_file <- paste( tmp_plot_dir, tmp_cnv_file_name[i], list.files(paste(tmp_plot_dir, tmp_cnv_file_name[i], sep = "/"), pattern = "ratio.txt$"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste("a549_10_4", tmp_cnv_file_name[i], sep = ", ") , 
                x_axis_lab = T,
                filename = paste(getwd(), "/", "a549_10_4","_",  tmp_cnv_file_name[i], ".png", sep = "") )
}

## 
tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/5534T_10_4"
tmp_cnv_file_name <- c("ploidy_2_resolution_40000_control", "ploidy_2_resolution_40000_map", "ploidy_2_resolution_40000_control_map")
for (i in 1:3 ) {
  tmp_cnv_file <- paste( tmp_plot_dir, tmp_cnv_file_name[i], list.files(paste(tmp_plot_dir, tmp_cnv_file_name[i], sep = "/"), pattern = "ratio.txt$"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste("5534T_10_4", tmp_cnv_file_name[i], sep = ", ") , 
                x_axis_lab = T,
                filename = paste(getwd(), "/", "5534T_10_4","_", tmp_cnv_file_name[i] , ".png", sep = "") )
}

tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/map/"
for (i in 1:9) {
  tmp_cnv_file_name <- paste( tmp_plot_dir,lung_cancer_samples[i], list.files(paste(tmp_plot_dir, lung_cancer_samples[i], sep = "/"), pattern = "*ratio.txt"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file_name, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste0(lung_cancer_samples[i], "_CNV_40kb_ploidy2_map") , 
                x_axis_lab = T,
                filename = paste0(tmp_plot_dir, "/", lung_cancer_samples[i],"_CNV_40kb_ploidy2_map", ".png") )
}

tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/contamination/"
for (i in 1:9) {
  tmp_cnv_file_name <- paste( tmp_plot_dir,lung_cancer_samples[i], list.files(paste(tmp_plot_dir, lung_cancer_samples[i], sep = "/"), pattern = "*ratio.txt"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file_name, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste0(lung_cancer_samples[i], "_CNV_40kb_ploidy2_contamination") , 
                x_axis_lab = T,
                filename = paste0(tmp_plot_dir, "/", lung_cancer_samples[i],"_CNV_40kb_ploidy2_contamination", ".png") )
}

####
tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/map_and_control/"
for (i in c(2:4, 6)) {
  tmp_cnv_file_name <- paste( tmp_plot_dir,lung_cancer_samples[i], list.files(paste(tmp_plot_dir, lung_cancer_samples[i], sep = "/"), pattern = "*ratio.txt"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file_name, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste0(lung_cancer_samples[i], "_CNV_40kb_ploidy2_map_and_control") , 
                x_axis_lab = T,
                filename = paste0(tmp_plot_dir, "/", lung_cancer_samples[i],"_CNV_40kb_ploidy2_map_and_control", ".png") )
}

#### map_and_contamination
tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/map_and_contamination/"
for (i in 1:9) {
  tmp_cnv_file_name <- paste( tmp_plot_dir,lung_cancer_samples[i], list.files(paste(tmp_plot_dir, lung_cancer_samples[i], sep = "/"), pattern = "*ratio.txt"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file_name, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 2, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste0(lung_cancer_samples[i], "_CNV_40kb_ploidy2_map_and_contamination") , 
                x_axis_lab = T,
                filename = paste0(tmp_plot_dir, "/", lung_cancer_samples[i],"_CNV_40kb_ploidy2_map_and_contamination", ".png") )
}

#### A549 ploidy3,map
tmp_plot_dir <- "/lustre/user/liclab/wupz/P9_BGI/Call_CNV_from_HiC/map_ploidy3/"
for (i in 7:9) {
  tmp_cnv_file_name <- paste( tmp_plot_dir,lung_cancer_samples[i], list.files(paste(tmp_plot_dir, lung_cancer_samples[i], sep = "/"), pattern = "*ratio.txt"), sep = "/")
  tmp_cnv_file <- read.table(file = tmp_cnv_file_name, 
                             header = T, stringsAsFactors = F)
  DrawCNVFigure(CNV_data = tmp_cnv_file, ploidy = 3, 
                mode = 'horizontal', xlab = "", ylab = '', 
                main = paste0(lung_cancer_samples[i], "_CNV_40kb_ploidy3_map") , 
                x_axis_lab = T,
                filename = paste0(tmp_plot_dir, "/", lung_cancer_samples[i],"_CNV_40kb_ploidy3_map", ".png") )
}

