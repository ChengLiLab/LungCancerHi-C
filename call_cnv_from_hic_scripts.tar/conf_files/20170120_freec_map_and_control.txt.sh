nohup freec -conf freec_config_5534T_10_4_win40kb_ploidy2_map_and_control.txt > freec_config_5534T_10_4_win40kb_ploidy2_map_and_control.txt.log 2>&1 &
nohup freec -conf freec_config_5534T_10_5_win40kb_ploidy2_map_and_control.txt > freec_config_5534T_10_5_win40kb_ploidy2_map_and_control.txt.log 2>&1 &
nohup freec -conf freec_config_5534T_10_6_win40kb_ploidy2_map_and_control.txt > freec_config_5534T_10_6_win40kb_ploidy2_map_and_control.txt.log 2>&1 &
nohup freec -conf freec_config_6405T_win40kb_ploidy2_map_and_control.txt > freec_config_6405T_win40kb_ploidy2_map_and_control.txt.log 2>&1 &
